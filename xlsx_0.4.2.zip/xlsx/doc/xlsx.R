### R code from vignette source 'xlsx.Rnw'

###################################################
### code chunk number 1: setup
###################################################
options(width=72, continue=" ")
require(xlsx)


