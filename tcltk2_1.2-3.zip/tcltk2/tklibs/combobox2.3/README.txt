Combobox version 2.3
Copyright (c) 1998-2003, Bryan Douglas Oakley
All Rights Reserved.

http://www.purl.org/net/oakley/tcl/combobox/index.html
mailto:oakley@bardo.clearlight.com

This software is provided AS-IS with no waranty expressed or
implied. This software may be used free of charge, though I would
appreciate it if you give credit where credit is due and mention my
name when you use it.

To use: place combobox.tcl where your programs can get at it either
via autoloading or from a "source" command. To create a combobox widget
use the command "::combobox::combobox", or import the combobox command
with "import ::combobox::*" to use it as simply "combobox".

To see a quick example, start up a wish process and cd to the directory
where combobox.tcl is located. Then do "source example.tcl".

#####################################################################
