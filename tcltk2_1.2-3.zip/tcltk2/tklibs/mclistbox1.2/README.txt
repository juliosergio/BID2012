Mclistbox version 1.02
Copyright (c) 1999, Bryan Douglas Oakley
All Rights Reserved.

http://purl.oclc.org/net/oakley/tcl/mclistbox/index.html
mailto:oakley@channelpoint.com

This software is provided AS-IS with no waranty expressed or
implied. This software may be used free of charge, though I would
appreciate it if you give credit where credit is due and mention my
name when you use it.

To use, place mclistbox.tcl where your programs can get at it either
via autoloading or from a "source" command. Then, use
"mclistbox::mclistbox" to create a mclistbox, or do "import
::mclistbox::*" to use the mclistbox command without the namespace qualifier.

To see a quick example, start up a wish process and cd to the directory
where mclistbox.tcl is located. Then do "source example.tcl".

To run some simple tests, source "test.tcl" or "mclistbox.test"

