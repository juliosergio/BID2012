clearlook ttk theme borrowed from PySolFC (GNU General Public License 3.0)
(see http://sourceforge.net/projects/pysolfc/).
